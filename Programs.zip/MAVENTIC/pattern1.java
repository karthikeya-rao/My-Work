import java.util.*;
import java.io.*;

public class pattern1{
	public static void main(String []args){
		int N;
		try{
			DataInputStream DIN = new DataInputStream(System.in);
			System.out.println("ENTER THE NUMBER : ");
			String s = DIN.readLine();
			N= Integer.parseInt(s);
			System.out.println();
			int i= 0 ,j = 0,k = 0;
			int NUM = 0;

			int P1 = N/2 , P2 = 1;
			for(i = 1;i <= N;i++){
				
				for(j = 1;j<= P1;j++){
					System.out.print(" ");
				}
				int count = P2/2+1;
				for(k = 1;k<= P2;k++){
					System.out.print(count);
					if(k<= P2/2){
						count--;
					}else{
						count++;
					}					
				}
				System.out.println();
				if(i<=N/2){
					P1 = P1-1;
					P2= P2+2;
				}else{
					P1 = P1+1;
					P2= P2-2;
				}			
			}
		}catch(Exception e){
			System.out.println(e);
		}
	}

}