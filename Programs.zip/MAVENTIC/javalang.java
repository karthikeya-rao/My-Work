//Write a program in java which takes a sentence as input from user and print the following :
//input: Java Language Concept Video Tutorial and Blogs
//Output: 9BlogsJava 11andLanguage 15TutorialConcept 5Video
import java.util.Scanner;
import java.util.Scanner;
public class javalang{

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String sentence;
        System.out.println("Enter The Sentence :");
        try{
            sentence=sc.nextLine();
            sc.close();
        }catch(Exception e){
            sentence="Java Language Concept Video Tutorial and Blogs";
            sc.close();
        }
        //convert to array from sentence
        String arr[]=sentence.split(sentence,' ');
        
        int size,length=arr.length;
        String temp;
        
        if(length%2==0)
            size=length/2;
        else
            size=length/2+1;
        
        for(int j=length-1,i=0;i<size;i++,j--){
            if(i!=j){
                temp=arr[j]+arr[i];
                System.out.print(temp.length()+temp+" ");
                temp="";
            }
            else
                System.out.println((arr[j]).length()+arr[j]);
        }
    }
    // count the length of string
    private static int getLength(String string) {
        int i=0,count = 0;
        while(true){
            try{
                if(string.charAt(i++)!='\0')                
                    count++;                
            }catch(StringIndexOutOfBoundsException e){
                return count;
            }
        }
    }
    

    private static int wordCount(String string){
        int i=0,count = 1;char ch;
        if(string.charAt(0)==' ')
            count=0;
        while(true){
            try{
                ch=string.charAt(i++);
                if((ch==' '&& string.charAt(i)!=' ')){
                    count++;            
                }
            }catch(StringIndexOutOfBoundsException e){

                return count;
            }
        }
    }
    //split the sentence according to given delimiter
    private static String[] getArray(String sentence, char delimeter) {
        int i=0,index=0;char ch;
        String[] str=new String[wordCount(sentence)];
        StringBuffer sb=new StringBuffer();
        while(true){                        
            try{
                ch=sentence.charAt(i++);
                if(ch==' '&& sentence.charAt(i)==' '){

                    continue;
                }else if(ch==' '){

                    if(getLength(sb.toString())!=0)
                    str[index++]=sb.toString();
                    sb=new StringBuffer();    
                }else         
                    sb.append(ch);        
            }catch(StringIndexOutOfBoundsException e){

                str[index]=sb.toString();                
                break;
            }            
        }
        return str;
    }
}