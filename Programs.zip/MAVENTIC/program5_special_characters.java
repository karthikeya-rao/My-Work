import java.util.*;
import java.io.*;
import java.lang.*;

public class program5_special_characters{

	public static void main(String []args){
		try{
			DataInputStream DIN = new DataInputStream(System.in);
			System.out.println("ENTER THE STRING : ");
			String s = DIN.readLine();
			System.out.println("THE STRING : "+s);
			char ch[] = s.toCharArray();
			int scount = 0;

			for(char c:ch){
				scount++;
			}
			
			String SF = "";
			System.out.println(getLength(s));

			for(int i=0;i<getLength(s);i++){
				int sum1 = 0;
				if(s.charAt(i)==' '){
					System.out.println(sum1+" ");
				}else{
					if(s.charAt(i)=='a' && s.charAt(i)=='A'){
						SF=SF+"@";
						sum1=sum1+1;
					}else if(s.charAt(i)=='e' && s.charAt(i)=='E'){
						SF=SF+"e#";
						sum1=sum1+1;
					}else if(s.charAt(i)=='m' && s.charAt(i)=='M'){
						SF=SF+"e#";
						sum1=sum1+1;
					}
				}
			}
			System.out.println(SF);
		}catch(Exception e){
			System.out.println(e);
		}
	}
 private static int getLength(String string) {
        int i=0,count = 0;
        while(true){
            try{
                if(string.charAt(i++)!='\0')                
                    count++;                
            }catch(StringIndexOutOfBoundsException e){
                return count;
            }
        }
    }
}