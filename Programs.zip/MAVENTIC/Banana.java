import java.util.*;
import java.io.*;

public class Banana{
	public static void main(String []args){
		try{
			DataInputStream DIN =  new DataInputStream(System.in);
			System.out.println("ENTER THE STRING ");
			String WORD  = DIN.readLine();
			char ch[] = WORD.toCharArray();
			int count = 0;
			for(char c:ch){
				count++;
			}
			for(int i=0;i<count;i++){
				int SUM = 0;
				for(int j=0;j<count;j++){
					if(ch[i] == ch[j]){
						SUM++;
					}
				}
			System.out.print(" "+ch[i]+""+SUM);
			}
			
		}catch(Exception e){
			System.out.println(e);	
		}
	}
}