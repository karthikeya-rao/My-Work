import java.util.*;
import java.io.*;

public class example1{
	
	public static void main(String args[]){
String str="1234";
String st1="";
String[] arr=new String[10];
char ch[]=str.toCharArray();
for(int i=0;i<ch.length;i++){
	char c=(ch.charAt(i));
	char c1=(ch.charAt(i+1));
	st1=c+c1;
	System.out.println(st1);
	}
}
}