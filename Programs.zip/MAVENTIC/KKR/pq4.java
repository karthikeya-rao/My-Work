import java.util.*;

class pq4{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the sentence");
		String str="";
		str=in.nextLine();
		str=str+" ";

		char ch[]=str.toCharArray();
		int count=0;
		for(char c:ch){
			count++;
		}
		String temp="";
		String maintemp="";
		for(int i=0;i<count;i++){
			if(ch[i]== ' '){
				
				char ch1[]=temp.toCharArray();
				int wcount=0;
				for(char c:ch1){
					wcount++;
				}
				maintemp=maintemp+temp+wcount+" ";
				wcount=0;
				temp="";
				
			}else{
				
				switch(ch[i]){
					case 'a':
					case 'A':temp=temp+'@';
						break;
					case 'e':
					case 'E':temp=temp+ch[i]+'#';
						break;
					case 'm':
					case 'M':temp=temp+ch[i]+'$';
						break;
					case 't':
					case 'T':temp=temp+ch[i]+'%';
						break;
					case 'i':
					case 'I':temp=temp+ch[i]+'&';
						break;
					default:temp=temp+ch[i];
						break;

				}
				//maintemp=maintemp+temp;
			
			}
			
		
		
		}
		System.out.println(maintemp);
	}
}