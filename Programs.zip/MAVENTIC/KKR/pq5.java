import java.io.*;
import java.util.*;

class pq5{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		System.out.println("Enter a word");
		String str="";
		str=in.nextLine();
		System.out.println("Enter a word to replace");
		String strRep;
		strRep=in.nextLine();
		
		char ch1[]=str.toCharArray();		
		char ch2[]=strRep.toCharArray();
	
		int count1=0,count2=0;		
		for(char c:ch1){
			count1++;
		}
		for(char c:ch2){
			count2++;
		}
		int count3=count1;
		
		String temp="";
		for(int i=0;i<count2;i++){
			for(int j=0;j<count1;j++){
				if(ch2[i]==ch1[j]){
					for(int f=j;f<count1-1;f++){
						ch1[f]=ch1[f+1];
						count3--;
						//count1--;
						
					}
				}
			}
						
		}
		
		for(int i=0;i<count3;i++){
			temp=temp+ch1[i];
		}
		System.out.println(temp);
	
				
		
		
				

	}
}