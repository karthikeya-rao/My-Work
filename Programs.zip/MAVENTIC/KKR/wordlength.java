import java.io.*;
import java.util.*;

class wordlength{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		String str=new String();
		System.out.println("Enter a String");
		str=in.nextLine();
		int count=0,words=1,newarr=0;
		char[] ch=str.toCharArray();
		for(char i:ch){
			count++;
			if(i==' '){
				words++;
			}			
		}
		String temp="";
		String[] newString=new String[words+1];
	try{
		for(int j=0;j<=count;j++){
			if(ch[j]!=' '){
				temp=temp+ch[j];			
			}else{
				char[] ch1=temp.toCharArray();
				int wordlength=0;
				for(char c:ch1){
					wordlength++;
				}	
				System.out.println("The length of "+temp+ " is "+wordlength);
				newString[newarr]=temp;
				newarr++;
				temp="";
			}
		}
		
		
		
	}catch(Exception e){
	//System.out.println(e);	
	}
		System.out.println("==============================");
		System.out.println("==============================");
		for(int i=0;i<words-1;i++){
			System.out.println(newString[i]);
		}
		
		System.out.println("==============================");
		System.out.println("==============================");
		String[] sorted=new String[words+1];
		for(int i=0;i<newarr;i++){
		for(int j=i;j<newarr-1;j++){
			int firstcount=0,secondcount=0;
			char[] first=newString[j].toCharArray();
			char[] second=newString[j+1].toCharArray();
			System.out.println("==============================");
			System.out.println("==============================");
			System.out.println("==============================");
		System.out.println("==============================");
			System.out.println(first);
			System.out.println(second);
			System.out.println("==============================");
		System.out.println("==============================");
		System.out.println("==============================");
		System.out.println("==============================");
			for(char c:first){
				firstcount++;
			}
			for(char c:second){
				secondcount++;
			}
			if(firstcount>secondcount){
				String temp1=newString[j];
				newString[j]=newString[j+1];
				newString[j+1]=temp1;
			}
			System.out.println(newString[j]);
		}
		}
		
		
	}	
}