import java.io.*;
import java.util.*;

class vowelremove{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		String str="";
		
		System.out.println("Enter a string");
		str=in.nextLine();
		str=str+" ";

		char ch[]=str.toCharArray();
		int count=0;
		
		
		for(char c:ch){
			count++;
		}
		String temp="";
		for(int i=0;i<count;i++){
			switch(ch[i]){
				case 'a':
				case 'e':
				case 'i':
				case 'o':
				case 'u':
				case 'A':
				case 'E':
				case 'I':
				case 'O':
				case 'U':temp=temp+"";
					break;
				default:temp=temp+ch[i];
					break;
			}
		}
			
		System.out.println(temp);
		}
}