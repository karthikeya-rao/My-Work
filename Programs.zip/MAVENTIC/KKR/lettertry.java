import java.io.*;
import java.util.*;

class lettertry{
	public String dup(String str,char ch,int index){
		char ch2[]=str.toCharArray();
		int count2=0;
		for(char c:ch2){
			count2++;
		}
		String temp2="";
		System.out.println(count2);
		for(int i=0;i<count2;i++){
			//System.out.println("Entering");
			if(i!=index){
				if(ch2[i]!=ch){
					temp2=temp2+ch2[i];	
				}
			}
		}
		return temp2;

	}
		
	public static void main(String args[]){
		lettertry m=new lettertry();
		Scanner in=new Scanner(System.in);
		String str="";
		System.out.println("Enter a string");
		str=in.nextLine();
		
		char ch1[]=str.toCharArray();
		int count=0;
		
		for(char c:ch1){
			count++;
		}
		
		String temp="";
		temp=temp+str;
		
		for(int i=0;i<count;i++){
			temp=m.dup(temp,ch1[i],i);
			 
		}
	
		System.out.println(temp);
	}
}