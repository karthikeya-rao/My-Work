import java.io.*;
import java.util.*;

class devstr{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		String str="";
		System.out.println("Enter the string");
		str=in.nextLine();


		char[] ch=str.toCharArray();
		int count=0;

		for(char c:ch){
			count++;
		}
		int[] arr=new int[count];
		
		for(int i=0;i<count;i++){
			arr[i]=ch[i];
		}
		
		for(int i=0;i<count;i++){
			for(int j=0;j<count-1;j++){
				if(arr[j]>arr[j+1]){
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		
		for(int i=0;i<count;i++){
			System.out.print(arr[i]+" ");
		}
		int[] arr2=new int[count];
		int[] arr3=new int[count];
		int count1=1;
		System.out.println("\n================");
		int k=0;
		int extracount=0;
		
		for(int i=0;i<count;i++){
		
			i=i+count1-1;			
			count1=0;
			for(int j=0;j<count-1;j++){
				if(arr[i]==arr[j]){
					count1++;										
				}				
				
			}
			arr2[k]=count1;
			arr3[k]=arr[i];
			k++;
			extracount++;
			
		}
		
		for(int i=0;i<extracount;i++){
			System.out.println((char)arr3[i]+" "+arr2[i]);
		}
		
	}
}