import java.io.*;
import java.util.*;

class strcompare{
	public static void main(String args[]){
	Scanner in=new Scanner(System.in);
	String str="";
	System.out.println("Enter a string");
	str=in.nextLine();
	String temp="";
	char[] ch=str.toCharArray();
	int count=0;
	for(char c:ch){
		count++;
		}
	System.out.println("The count is "+count);
	System.out.println("===================");
	
	for(int i=0;i<count;i++ ){
		if(ch[i]!=' '){
			temp=temp+ch[i];
			
		}else{	
			
			int wordcount=0;
			char[] ch1=temp.toCharArray();
			for(char c:ch1){
				wordcount++;
			}
			//System.out.println(temp);
			int first=ch1[0];
			int last=ch1[wordcount-1];
			if(first==last){
			System.out.println("First and last letters of "+temp+" is "+first+" and "+last+" and is same");
			}else{
			System.out.println("First and last letters of "+temp+" is "+first+" and "+last+" and is NOT same");
			}
			temp="";
			
						
		
		}
		
	}
	}
}