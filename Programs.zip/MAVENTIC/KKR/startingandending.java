import java.io.*;
import java.util.*;

class startingandending{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		String str="";
		String str1="";
		String str2="";
		System.out.println("Enter the string");
		str2=in.nextLine();
		System.out.println("Enter the second String");
		str1=in.nextLine();
		
		str=str2+str1;	
		
		char[] ch=str.toCharArray();
		int count=0;
		for(char c:ch){
			count++;
		}

		System.out.println("Length of the String is "+count);
		String temp="";
		String temp1="";

		for(int i=0;i<count;i++){
			if(ch[i]!=' '){
				temp=temp+ch[i];			
			}else{
				int wordcount=0;
				char[] ch1=temp.toCharArray();
				
				for(char c1:ch1){
					wordcount++;
				}
				int asc=0;
				for(int j=0;j<wordcount;j++){
					asc=ch1[j];
					if(asc<97){
						System.out.print(ch1[j]+" ");
						temp1=temp1+ch1[j];
							
					}
				}
				temp="";
								
			}			
		}
		int seccount=0;
		char[] ch2=temp1.toCharArray();
		for(char c:ch2){
			seccount++;
		}
		int wordcount2=0;
		for(int i=0;i<seccount;i++){
			wordcount2=0;
			for(int j=0;j<seccount;j++){
				if(ch2[i]==ch2[j]){
					wordcount2++;
				}
				
			}
			System.out.println("\n"+ch2[i]+" is "+wordcount2);	
		}
	}

}