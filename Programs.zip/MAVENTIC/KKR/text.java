import java.io.*;
import java.util.*;
class text{
	public static void main(String args[]){
	Scanner in=new Scanner(System.in);
	char[] ch=new char[10];
	char[] mainch=new char[20];
	int asc,temp,n;
	System.out.println("how many characters do you want to enter?");
	n=in.nextInt();
	for(int i=0;i<n;i++){
	System.out.println("Enter a character");
	ch[i]=in.nextChar();
	mainch[i]=ch[i];
	asc=ch[i];
	System.out.println("Enter the next character");
	ch[i+1]=in.nextChar();
	temp=ch[i+1];
	
	if(asc+1==temp){
		mainch[i+1]=ch[i+1];	
	}
	
	for(int j=0;j<n;j++){
	System.out.println(mainch[j]);
	}
	}
	
	}
}