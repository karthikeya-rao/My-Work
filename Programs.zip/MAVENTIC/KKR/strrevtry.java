import java.io.*;
import java.util.*;

class strrevtry{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the string");
		String str="";
		str=in.nextLine();

		char ch[]=str.toCharArray();

		int count=0;
		for(char c:ch){
			count++;
		}
		
		//System.out.println(ch[count-1]);
		String temp="";
		for(int i=count-1;i>=0;i--){
			temp=temp+ch[i];
		}
		System.out.println(temp);
		
		char ch1[]=temp.toCharArray();
		int flag=0;
		
		for(int i=0;i<count;i++){
			if(ch[i]==ch1[i]){
					flag++;
			}
		}
		if(flag==count){
			System.out.println("This is a palindrome");
		}else{
			System.out.println("This is not a palindrome");
		}
	}
}