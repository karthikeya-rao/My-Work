import java.io.DataInputStream;
import java.util.Arrays;

public class rearrange_letter {

    public static void rearrange_word(String str) {
        char tempArray[] = str.toCharArray();
        int count;
        Arrays.sort(tempArray);

        for (int i = 0; i &lt; str.length; i++) {
            count = 0;
            for (int j = 0; j &lt; str.length; j++) {
                if (tempArray[i] == tempArray[j]) {
                    count++;
                }
            }

            if (count &lt;= 1) {
                System.out.print(tempArray[i]);
            }
        }

    }

    public static void main(String[] args) {
        DataInputStream in = new DataInputStream(System.in);
        String line = "";
        try {
            System.out.print("Enter the Word : ");
            line = in.readLine();

            System.out.print("Word after re-arranging with no duplicates : ");
            rearrange_word(line);
            System.out.println("");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}