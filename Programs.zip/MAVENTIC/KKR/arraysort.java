import java.io.*;
import java.util.*;

class arraysort{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the size of the first array");
		int size=in.nextInt();
		System.out.println("\nEnter the size of the second array");
		int size2=in.nextInt();
				
		int index=0;
		int[] arr3=new int[size+size2];
		System.out.println("");
		System.out.println("Enter the elements for the first element");
		int[] arr1=new int[size];
		for(int i=0;i<size;i++){
			arr1[i]=in.nextInt();
		}
		int temp=0;
		for(int i=0;i<size;i++){
			for(int j=0;j<size-1;j++){
				if(arr1[j]>arr1[j+1]){
					temp=arr1[j];
					arr1[j]=arr1[j+1];
					arr1[j+1]=temp;
				}	
			}
		}
		System.out.println("");
		System.out.println("=======================");
		for(int i=0;i<size;i++){
			System.out.print(arr1[i]+" ");
			arr3[index]=arr1[i];
			index++;
		}

		System.out.println("");
		System.out.println("Enter the elements for second array");
		
		int[] arr2=new int[size2];
		for(int i=0;i<size2;i++){
			arr2[i]=in.nextInt();
		}
		temp=0;
		for(int i=0;i<size2;i++){
			for(int j=0;j<size2-1;j++){
				if(arr2[j]>arr2[j+1]){
					temp=arr2[j];
					arr2[j]=arr2[j+1];
					arr2[j+1]=temp;
				}	
			}
		}
		System.out.println("=======================");		
		for(int i=0;i<size2;i++){
			System.out.print(arr2[i]+" ");
			arr3[index]=arr2[i];
			index++;
		}

		temp=0;
		for(int i=0;i<size2+size;i++){
			for(int j=0;j<(size+size2)-1;j++){
				if(arr3[j]>arr3[j+1]){
					temp=arr3[j];
					arr3[j]=arr3[j+1];
					arr3[j+1]=temp;
				}	
			}
		}
		System.out.println("");
		System.out.println("COMBINING AND SORTING");
		System.out.println("=======================");
		for(int i=0;i<size2+size;i++){
			System.out.print(arr3[i]+" ");
		}

		
		

	}
}