import java.io.*;
import java.util.*;

class strremove{

	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		String str="";
		System.out.println("Enter a String");
		str=in.nextLine();

		int count=0;
		char[] ch=str.toCharArray();

		for(char c:ch){
			count++;
		}
		int rep=0;
		String temp="";
		temp=str;
		int k=0;
		char[] ch1=temp.toCharArray();
		char[] ch2= new char[10];
		for(int i=0;i<count;i++){
			for(int j=i;j<count;j++){
				if(i!=j){
					if(ch[i]==ch1[j]){
						rep++;
						System.out.println(ch[i]);
						ch2[k]=ch[i];
						k++;
					}
				}
			}
		}
		int repcount=0;
		for(char c:ch2){
		repcount++;
		}
		String temp2="";
		int index=0;
		for(int i=0;i<count;i++){
			for(int j=0;j<repcount;j++){
				if(ch[i]==ch2[j]){
					temp2=temp2+ch[i];
					index=i;	
				}
			}	
			
		}
		ch[index]=' ';
		System.out.println("=================");
		System.out.println("=================");
			
		for(int i=0;i<count;i++){
			System.out.println(ch[i]);
		}
		System.out.println("=================");
		System.out.println("=================");
		
		//System.out.println("Number of repeated characters are"+repcount);
		System.out.println("=================");
		System.out.println("=================");
		System.out.println(temp2);
		System.out.println("The index is"+index);
	}
}