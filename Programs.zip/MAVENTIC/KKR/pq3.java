//import java.io.*;
import java.util.*;

class pq3{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		System.out.println("Enter a string");
		String str="";
		str=in.nextLine();

	

		char ch[]=str.toCharArray();
		int count=0;
		for(char c:ch){
			count++;
		}
	
		String temp="";
		int wcount=0;
		int arr,arr1;
		for(int i=0;i<count;i++){
			arr=ch[i];
			arr=arr+32;
			arr1=ch[i];
			arr1=arr1-32;
			
			System.out.println(arr);
			for(int j=0;j<count;j++){
				if(ch[i]==ch[j] || arr==ch[j] || arr1==ch[j]){
					wcount++;
				}
			}
			temp=temp+ch[i];
			temp=temp+wcount;
			wcount=0;
			
		}
		System.out.println("The string is "+temp);
	}
}