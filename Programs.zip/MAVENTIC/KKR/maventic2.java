import java.io.*;
import java.util.*;

class maventic2{

	
	public static void main(String args[]){
	
		Scanner in=new Scanner(System.in);
		String str="";
		System.out.println("Enter a letter");
		str=in.nextLine();
		str=str+" ";
		int count=0;

		char[] ch=str.toCharArray();
		for(char c:ch){
			count++;
		}
		String temp="";
		int j=0;
		char[] temp1=new char[count];
		temp1[0]=ch[0];
		for(int i=0;i<count;i++){
				
			j++;
			for(int k=0;k<j-1;k++){
				if(ch[i]!=temp1[k]){
					temp1[j]=ch[i];
				}
			}			
			
		}
		
		for(int i=0;i<j-1;i++){	
			System.out.println(temp1[i]);
		}

	}
}