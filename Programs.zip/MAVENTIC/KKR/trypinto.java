import java.util.*;
class trypinto{
	public static void main(String args[]){
		int count=0;
		int count1=0;
		Scanner in=new Scanner(System.in);
		System.out.println("enter a string");
		String str="";
		str=in.nextLine();
		char[] a=str.toCharArray();
		for(char c:a){
			count++;
		
		}
		System.out.println(count);
		System.out.println("enter the second String");
		String str1="";
		str1=in.nextLine();
		char[] b=str1.toCharArray();
		for(char d:b){
			count1++;
					
		}
		if(count==count1){
		for(int i=0;i<count;i++){
			if(a[i]==b[i]){

		System.out.println("equal");

		}else{
		System.out.println("not equal");
		}
}		
		}else{

		System.out.println("not equal");
		}
		
	}
}