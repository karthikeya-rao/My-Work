import java.util.*;
import java.io.*;
class pat1{
	public static void main(String []args){ 
	
		System.out.println("hello");
	}

}