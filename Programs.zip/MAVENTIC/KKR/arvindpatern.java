import java.io.*;
import java.util.*;

class arvindpatern{
	
	public String rem(String str,char ch){
		char ch1[]=str.toCharArray();
		int count=0;
		for(char c:ch1){
			count++;
		}
		String temp="";
		for(int i=0;i<count;i++){
			if(ch1[i]!=ch){
				temp=temp+ch1[i];
			}
		}
		return temp;

	}	
	
	

	public static void main(String args[]){
		arvindpatern ap=new arvindpatern();
		Scanner in=new Scanner(System.in);
		String str1="";
		System.out.println("Enter a string");
		str1=in.nextLine();

		String str2="";
		System.out.println("Enter another string");
		str2=in.nextLine();
		
	
	
		char ch2[]=str2.toCharArray();
		int count2=0;
		for(char c:ch2){
			count2++;
		}

	
		String temp1="";
		temp1=temp1+str1;
		
		for(int i=0;i<count2;i++){
			temp1=ap.rem(temp1,ch2[i]);			
		}
	
		System.out.println(temp1);
	}
}