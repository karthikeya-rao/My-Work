import java.io.*;
import java.util.*;

class strcompare{
}