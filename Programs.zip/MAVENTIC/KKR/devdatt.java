import java.util.*;

class devdatt{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		System.out.println("Enter a string");
		String str="";
		str=in.nextLine();
		
		char ch[]=str.toCharArray();
		int count=0;
		for(char c:ch){
			count++;
		}
		int[] arr=new int[count];
		
		for(int i=0;i<count;i++){
			arr[i]=ch[i];
		}
		
		for(int i=0;i<count;i++){
			for(int j=0;j<count-1;j++){
				if(arr[j]>arr[j+1]){
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}	
		}
		int wcount=0,index=0,temp=0;
		for(int i=0;i<count;i=i+temp){
			
			for(int j=0;j<count;j++){
				if(arr[i]==arr[j]){
					wcount++;
				}
			}
			System.out.println((char)arr[i]+" "+wcount);
			temp=wcount;
			wcount=0;
		}

	}
}