import java.io.*;
import java.util.*;

class daksh{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		String str="";
		System.out.println("Enter a string");
		
		char ch[]=str.toCharArray();
		
		int count=0;
		for(char c:ch){
			count++;		
		}
		int[] arr=new int[count];
		for(int i=0;i<count;i++){
			arr[i]=ch[i];
		}
		System.out.println("THE OUTPUT IS");
		for(int i=0;i<count;i++){
			System.out.println(arr[i]);	
		}
	}
}