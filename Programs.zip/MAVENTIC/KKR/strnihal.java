import java.io.*;
import java.util.*;

class strnihal{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		System.out.println("Enter a String");
		String str="";
		str=in.nextLine();

		int count=0;
		char[] ch=str.toCharArray();

		for(char c:ch){
			count++;
		}
		int[] arr=new int[count];
		for(int i=0;i<count;i++){
			arr[i]=ch[i];
			//System.out.println(arr[i]);
		}
		int temp=0;
		char temp1;
	/*	for(int i=0;i<count;i++){
			for(int j=0;j<count-1;j++){
				if(arr[j]>arr[j+1]){
					temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
					//temp1=ch[j];
					//ch[j]=ch[j+1];
					//ch[j+1]=temp1;
					
				}
			}
		}		*/
		
		int j=0;
		int[] temp5=new int[count];
		
		for(int i=0;i<count;i++){
			if(arr[i]!=arr[i+1]){
			 temp5[++j]=arr[i];
			System.out.println(temp5[j]);
				
				
			}
		
		
		}
		
				
	/*	for(int i=0;i<count-1;i++){
			if(arr[i]==arr[i+1]){
				arr[i]=arr[i+1];
			}
		}
		for(int i=0;i<count;i++){
			ch[i]=(char)arr[i];
		}*/

			
	}

}