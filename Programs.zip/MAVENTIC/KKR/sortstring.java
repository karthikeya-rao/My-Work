import java.io.*;
import java.util.*;

class sortstring{
	public static void main(String args[]){
try{		Scanner in=new Scanner(System.in);
		System.out.println("Enter a String");
		String str=in.nextLine();
		str=str+" ";
		
		char[] ch1=str.toCharArray();
		int count=0,wordcount=0;
		int words=0;
		for(char c:ch1){
			count++;
			if(c==' '){
				words++;
			}
			
		}
		String[] strmain=new String[words];
		
		System.out.println("The words are "+words);
		String temp="";
		int[] arr=new int[words];
		int j=0;
		for(int i=0;i<count;i++){
			if(ch1[i]!=' '){
				temp=temp+ch1[i];
			}else{
				wordcount=0;
				char[] ch2=temp.toCharArray();
				for(char c:ch2){
					wordcount++;
				}
				arr[j]=wordcount;
				strmain[j]=temp;
				System.out.println("The length of the word "+strmain[j]+" is "+arr[j]);
				temp="";
				j++;
			}
		}
		
		String temp1="";
		int tempint;
		for(int i=0;i<words;i++){
			for(j=0;j<words-1;j++){
				if(arr[j]>arr[j+1]){
					temp1=strmain[j];
					strmain[j]=strmain[j+1];
					strmain[j+1]=temp1;
					tempint=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=tempint;
					
				
				}
			}
		}
		
		j=1;

		
		for(int i=0;i<words;i++){
			System.out.print(strmain[i]);
			
			if(arr[i]!=arr[j]){
				System.out.print(" "+arr[i]+" ");
						
			}
			j++;
			if(i==(words-1)){
				System.out.print(arr[words-1]);
			}
		}
				
	
	}catch(Exception e){ //System.out.println(e);
	}
}
}