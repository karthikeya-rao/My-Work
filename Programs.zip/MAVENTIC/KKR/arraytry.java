import java.io.*;
import java.util.*;

class arraytry{
	public static void main(String args[]){
	Scanner in=new Scanner(System.in);
	System.out.println("Enter the size");
	int size=in.nextInt();
		
	System.out.println("Enter the elements");
	int[] arr1=new int[size];	
	for(int i=0;i<size;i++){
		arr1[i]=in.nextInt();
	}
	System.out.println("Enter the element you want to search");
	int sear=in.nextInt();
	int flag=0,index=0;
	for(int i=0;i<size;i++){
		if(sear==arr1[i]){
			flag++;
			index=i+1;	
		}
	}
	if(flag>=1){
		System.out.println("The element is found at "+index+" location");
	}else{
		System.out.println("The element is not found");
	
	}
	
	
	System.out.println("Enter the second array");
	int[] arr2=new int[size];
	for(int i=0;i<size;i++){
		arr2[i]=in.nextInt();
	}
	int matchcheck=0;
	
	for(int i=0;i<size;i++){
		if(arr1[i]==arr2[i]){
			matchcheck++;		
		}
	}
	
	if(matchcheck==size){
		System.out.println("This is a perfect match");
	}else{
		System.out.println("This is not a perfect match");
	}

	
	

	
	}
}