import java.util.*;

class mavtry{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		System.out.println("Enter a string");
		String str="";
		str=in.nextLine();
		
		char ch[]=str.toCharArray();
		int[] arr=new int[str.length()+1];
		int count=str.length();
		for(int i=0;i<count;i++){
			arr[i]=ch[i];
		}
		
		for(int i=0;i<count;i++){
			for(int j=0;j<count-1;j++){
				if(arr[j]>arr[j+1]){
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		
		for(int i=0;i<count;i++){
			if(arr[i]!=arr[i+1]){
				System.out.println((char)arr[i]);
			}	
		}
	}
}