import java.io.*;
import java.util.*;
	
class abhitry{
	
public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		String str="";
		System.out.println("Enter a string");
		str=in.nextLine();
		str=str+" ";
		
		char[] ch=str.toCharArray();
		int count=-1;
		for(char c:ch){
			count++;
		}
		int temp=count;
		int loop=1;
		while(temp>0){
			loop=loop*temp;
			temp--;
		}
		
		System.out.println(loop);
		
		for(int i=0;i<loop;i++){
			for(int j=0;j<count;j++){
				
				
				System.out.print(ch[j]);
			}
			System.out.println("");
		}
	}
}