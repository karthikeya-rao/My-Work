import java.io.*;
import java.util.*;

class strnisc{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		String str="";
		System.out.println("Enter a string");
		str=in.nextLine();
		str=str+" ";
		
		int count=0;
		char[] ch=str.toCharArray();
		for(char c:ch){
			count++;
		}
		
		int[] arr=new int[count];
		
		for(int i=0;i<count;i++){
			arr[i]=ch[i];
			System.out.println(arr[i]);
		}
		int temp;
		for(int i=0;i<count;i++){
			for(int j=0;j<count-1;j++){
				if(arr[j]>arr[j+1]){
					temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;	
				}
			}
		}
		
		for(int i=0;i<count;i++){
			ch[i]=(char)arr[i];
			System.out.print(ch[i]);
		}
		System.out.println(" ");
		int repcount=0;
		for(int i=0;i<count;i++){
			for(int j=i;j<count;j++){
				if(i!=j){
					if(arr[i]==arr[j]){
						repcount++;
					}
				}
			}			
		}
		int[] arr1=new int[count];
		int k=0;
		for(int i=1;i<count;i++){
			if(arr[i-1]!=arr[i]){
				arr1[k]=arr[i];	
				k++;			
			}			
		}
		System.out.println("====================");
		System.out.println(k);
		System.out.println("====================");
		
		for(int i=0;i<(count-repcount);i++){
			System.out.println(arr1[i]);
		}
		
		for(int i=0;i<(count-repcount);i++){
			ch[i]=(char)arr1[i];
			System.out.print(ch[i]);
		}
		
	
	}
}