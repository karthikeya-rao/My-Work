import java.io.*;
import java.util.*;

class strmav1{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		String str1="";
		String str2="";
		System.out.println("Enter first string");
		str1=in.nextLine();
	
		System.out.println("Enter the second string");
		str2=in.nextLine();
	
		char[] ch1=str1.toCharArray();
		char[] ch2=str2.toCharArray();
		int count1=0,count2=0;
		for(char c:ch1){
			count1++;
		}
		for(char c:ch2){
			count2++;
		}
		String temp="";
		
		if(count1!=count2){
			System.out.println("These are not equal");
		}else{
			for(int i=0;i<count1;i++){
				for(int j=0;j<count2;j++){
					if(ch1[i]!=ch2[j]){
						temp=temp+ch1[i];
						System.out.println(ch2[i]);

					}
				}
			}
			
		}

		
	}
}