import java.io.*;
import java.util.*;

class pq5try{
	public static void main(String args[]){
		
		Scanner in=new Scanner(System.in);
		System.out.println("Enter a string");
		String str="";
		str=in.nextLine();
		
		System.out.println("Enter the letter to remove");
		String str1="";
		str1=in.nextLine();
		
		char ch1[]=str.toCharArray();
		char ch2[]=str1.toCharArray();
		int count=0,count1=0,count2=0;
		
		for(char c:ch1){
			count++;
		}
		String temp="";
		count1=count;
		for(char c:ch2){
			count2++;	
		}
		int c=0;
	for(int j=0;j<count;j++){
		for(int i=0;i<count2;i++){
			if(ch1[j]!=ch2[i]){
				temp=temp+ch1[i];
				 
			}else{
				count1--;
				
			}
		}
	}
		
		System.out.println(temp);

	}

}