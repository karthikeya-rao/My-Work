import java.io.*;
import java.util.*;

class strmav1simple{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		
		String str1="";
		String str2="";
		
		System.out.println("Enter the first string");
		str1=in.nextLine();

		System.out.println("Enter the second string");
		str2=in.nextLine();


		char[] ch1=str1.toCharArray();
		char[] ch2=str2.toCharArray();


		int count1=0,count2=0;
	
	
		for(char c:ch1){
			count1++;	
		}
		for(char c:ch2){
			count2++;
		}

		
		if(count1!=count2){
			System.out.println("Entered string is not equal");
		}else{
			int[] arr1=new int[count1];
			int[] arr2=new int[count2];
		
			for(int i=0;i<count1;i++){
				arr1[i]=ch1[i];
				arr2[i]=ch2[i];
			}
			
			for(int i=0;i<count1;i++){
				for(int j=0;j<count1-1;j++){
					if(arr1[j]>arr1[j+1]){
						int temp=arr1[j];
						arr1[j]=arr1[j+1];
						arr1[j+1]=temp;
					}
				}
			}
			
			for(int i=0;i<count1;i++){
				for(int j=0;j<count1-1;j++){
					if(arr2[j]>arr2[j+1]){
						int temp=arr2[j];
						arr2[j]=arr2[j+1];
						arr2[j+1]=temp;
					}
				}
			}
			
			for(int i=0;i<count1;i++){
				System.out.println(arr1[i]);
			}
	
			int maincount=0;
			for(int i=0;i<count1;i++){
				if(arr1[i]==arr2[i]){
					maincount++;
				}
			}
				
			if(maincount==count1){
				System.out.println("Entered strings are similar");
			}else{
				System.out.println("Entered strings are not equal");
			}
			
			System.out.println("The main count of the equals are "+maincount);
			
		}

	}

}