import java.io.*;
import java.util.*;

class pq6{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		System.out.println("Enter a string");
		String str="";
		str=in.nextLine();
		char ch[]=str.toCharArray();		
		int count=0;
		for(char c:ch){
			count++;
		}
		String temp="";
		for(int i=count;i>0;i--){
			temp=temp+ch[i];
		}
		
		System.out.println(temp);
	}
}