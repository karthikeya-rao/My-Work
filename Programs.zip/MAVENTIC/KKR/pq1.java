import java.io.*;
import java.util.*;

class pq1{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		String str="";
		System.out.println("Enter a date(dd/mm/yyyy)");
		str=in.nextLine();
		
		char ch[]=str.toCharArray();
		int count=0;
		for(char c:ch){
			count++;
		}
		
		String[] newStr=str.split("/");
		int[] arr=new int[3];
		for(int i=0;i<3;i++){
			//System.out.println(newStr[i]);
			arr[i]=Integer.parseInt(newStr[i]);
			
		}
		if(count<=8){
			System.out.println("Invalid");
			
		}
		else{
		int count1=0;
		for(int i=0;i<3;i++){
			switch(i){
				case 0: int dd=arr[i];
					if(dd>=01 && dd<=31){
						count1++;
					}
					break;
				case 1: int mm=arr[i];
					if(mm>=01 && mm<=12){
						count1++;
					}
					break;
				case 2: int yyyy=arr[i];
					if(yyyy>1950 && yyyy<2100){
						if((yyyy%4)==0){
							count1++;
						}
					}
					break;
				
			}
		}

			
		if(count1==3){
			System.out.println("valid");	
		}else{
			System.out.println("NOT VALID");
		}
	}
}
}