import java.util.*;
import java.io.*;
import java.lang.*;
public class sumstring{

	public static void main(String []args){
		String str = "I came to Maventic";
		char []ch = str.toCharArray();
		String  word[] = str.split(" ");
		
		int count = 0,N,i,j;
		for(String c:word){
			count++;
		}
		
		System.out.println(count);
		for(i=0;i<word.length;i++){
			System.out.println(word[i]);
		}



		for(i=0;i<word.length;i++){ 
			int sum = 0;
			for(j=0;j<word[i].length();j++){
				int char1 = word[i].charAt(j);
				if(char1 >96){
					sum=sum+(char1-96);
				}	
				if((char1>64 && char1<=92)){
					sum=sum+(char1-38);
				}
			}
			System.out.print(" "+sum);
		}
	}
}