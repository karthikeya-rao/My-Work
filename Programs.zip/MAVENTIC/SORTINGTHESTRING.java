/*****************************************
REMOVE THE DUPLICATES AND SORT THEM
******************************************/
import java.util.*;
import java.lang.*;
import java.io.*;

public class Main {

    public static void main(String[] args)throws IOException {
       // String s = "Karthikeya @# hsd@#$%^ Rao how123";
        try { 
            DataInputStream din = new DataInputStream(System.in);
            String s = din.readLine();
            s = s.toUpperCase();
            String s2 = "";
            String s3 = "";
            int Arr[] =  new int[250] ;
            for (int i = 0; i < s.length(); i++) {
                Boolean found = false;
                for (int j = 0; j < s2.length(); j++) {
                    if (s.charAt(i) == s2.charAt(j)) {
                        found = true;
                        break; //don't need to iterate further
                    }
                }
                if (found == false) {
                    s2 = s2.concat(String.valueOf(s.charAt(i)));
                    s3 = s3 + s.charAt(i);
                }
            }
            
            System.out.println("BEFORE SORTING ::"+s3);
            char[] charArray = s3.toCharArray();
            int length = charArray.length;
    
            for(int i=0;i<length;i++){
                for(int j=i+1;j<length;j++){
                    if (charArray[j] < charArray[i]) {
                        char temp = charArray[i];
                        charArray[i]=charArray[j];
                        charArray[j]=temp;
                    }
                }
            }
            System.out.println(charArray);
        }catch(Exception e) 
        { 
            System.out.println("Cannot Open the Input File"); 
            return; 
        } 
    }
}
