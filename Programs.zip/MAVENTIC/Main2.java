/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
import java.io.*;

public class Main2 {
    static Scanner con=new Scanner (System.in);
    public static void main(String[] args) {
        String s =  con.next();
        s = s.toUpperCase();
        String s2 = "";
        String s3 = "";
        int Arr[] =  new int[25] ;
        for (int i = 0; i < s.length(); i++) {
            Boolean found = false;
            for (int j = 0; j < s2.length(); j++) {
                if (s.charAt(i) == s2.charAt(j)) {
                    found = true;
                    break; //don't need to iterate further
                }
            }
            if (found == false) {
                s2 = s2.concat(String.valueOf(s.charAt(i)));
                s3 = s3 + s.charAt(i);
                Arr[i] = (int)s.charAt(i);
        //System.out.println(Arr);
            }
        }
        String result = "";
        

        for(int i = 1; i < s3.length(); i++)
        {
            if(s3.charAt(i-1) < s3.charAt(i))
                result += s3.charAt(i-1);
        }
        System.out.println(result);
    
        System.out.println(s2);
        System.out.println(s3);
        System.out.println(Arr);
    }
}
