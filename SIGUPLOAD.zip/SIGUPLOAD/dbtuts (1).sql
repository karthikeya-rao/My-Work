-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 26, 2018 at 11:45 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbtuts`
--
CREATE DATABASE IF NOT EXISTS `dbtuts` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dbtuts`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_uploads`
--

CREATE TABLE IF NOT EXISTS `tbl_uploads` (
  `F_NAME` varchar(100) NOT NULL,
  `F_TYPE` varchar(100) NOT NULL,
  `PATH` varchar(100) NOT NULL,
  `UPLOADED_BY` varchar(100) NOT NULL,
  `DATE_TIME` datetime NOT NULL,
  `OPERATION` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_uploads`
--

INSERT INTO `tbl_uploads` (`F_NAME`, `F_TYPE`, `PATH`, `UPLOADED_BY`, `DATE_TIME`, `OPERATION`) VALUES
('-uploads-Notes-btech-1sem-Computer_Generations.pdf', 'FILE', '/Essentials/Faculty 2/TEST/', 'Faculty 2', '2018-03-26 11:12:16', 'CREATE'),
('win100.jpg', 'FILE', '/Essentials/Faculty 2/TEST/', 'Faculty 2', '2018-03-26 11:23:51', 'CREATE'),
('DSC03927.JPG', 'FILE', '/Essentials/Faculty 2/TEST/', 'Faculty 2', '2018-03-26 11:42:06', 'CREATE'),
('12240000_1035100039885854_6596004118312473668_n.jpg', 'FILE', '/Essentials/Faculty 2/TEST/', 'Faculty 2', '2018-03-26 11:43:28', 'CREATE');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
