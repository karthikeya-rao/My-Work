<?php
include_once 'dbconfig.php';
$_SESSION["type"]="Faculty";
if ($_SESSION["type"]!="Faculty") {
	header("Location:index.php");
}
$_SESSION["fac_name"]="Faculty 2";
$fac_name = $_SESSION["fac_name"];
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?php echo $fac_name;  ?>'s Documents</title>
	<link rel="stylesheet" href="style.css" type="text/css" />

</head>
<body>
	<?php
	if(!isset($_GET["dir"])){
		header('location:faculty_directory.php?dir=/Essentials/'.$fac_name.'/');
	}
	$dir = $_GET["dir"];
	$directory = "/wamp/www/SIGUPLOAD".$dir;
	$needle = "/wamp/www/SIGUPLOAD/Essentials/".$fac_name;
	if(!preg_match('/^' . preg_quote($needle, '/') . '/', $directory)){
		header('location:faculty_directory.php?dir=/Essentials/'.$fac_name.'/');	
	}
	?>
	<div id="header">
		<label>Essentials</label>
	</div>
	<div id="body">
		<table width="80%" border="0">
			<tr>
				<td>Name</td>
				<td>File Type</td>
				<td>File Size</td>
			</tr>
			<?php
            //get all files in specified directory
			$files = glob($directory . "*");
			if (empty($files)) {
				?>
				<tr>
					<td colspan="3">
						Nothing to show
					</td>
				</tr>
				<?php
			}
			//print each file name
			foreach($files as $file)
			{
				//check to see if the file is a folder/directory
				?><tr align="left"><?php
				if(is_dir($file))
				{
					$ndir = str_replace("/wamp/www/SIGUPLOAD",'', $file);
					$address="faculty_directory.php?dir=".$ndir."/";
					?>
					<td colspan="3"><a href="<?php echo $address; ?>"><?php echo basename($file);?></a>
						<form action="upload.php" method="post">
							<input type="hidden" name="file" value="<?php echo $file ?>">
							<button type="submit" name="del_dir">Delete</button>
						</form>
					</td>
					<?php
				}else{
					?>
					<td><?php echo basename($file); ?>
						<?php $ndir = str_replace("/wamp/www",'', $file); ?> 
						(<a href="<?php echo $ndir ?>" target="_blank">view</a>)
						<form action="upload.php" method="post">
							<input type="hidden" name="file" value="<?php echo $file ?>">
							<button type="submit" name="del_file">Delete</button>
						</form>
					</td>
					<td><?php echo pathinfo($file, PATHINFO_EXTENSION); ?></td>
					<td><?php $kb = round(filesize($file)/1024);
					echo $kb." KiloBytes"; ?></td>
					<?php
				}
				?></tr><?php
			}
			if($dir != '/Essentials/'.$fac_name."/"){
				$temp = rtrim($dir,'/');
				while(substr($temp, -1) != "/"){
					$temp = substr($temp, 0, -1);
				}
				$address ="faculty_directory.php?dir=".$temp;
				?>
				<tr align="left">
					<td colspan ="3"><a href="<?php echo $address; ?>">Back</a></td>
				</tr>
				<?php
			}
			?>
			<tr>
				<td>
					Create a Subfolder Here:<br>
					<form action="upload.php" method="post" enctype="multipart/form-data">
						<input type="hidden" name="dir" id="dir" value="<?php echo $directory ?>" ><br>
						<input type="text" name="new_dir" placeholder="Enter Name of the Folder">
						<button type="submit" name="dir-upload">Create</button>
					</form>
				</td>
				<td>
					Upload a New File Here:
					<form action="upload.php" method="post" enctype="multipart/form-data" id="fileform"  >
						<input type="hidden" name="dir" id="dir" value="<?php echo $directory ?>" ><br>
						<input type="file" name="file" />
						<button type="submit" name="file-upload">upload</button>
					</form>
				</td>
			</tr>
		</table>
	</div>
</body>
</html>