<?php
include_once 'dbconfig.php';

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Essentials</title>
    <link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>
    <?php
    if(!isset($_GET["dir"])){
        header('location:Essentials.php?dir=/Essentials/');
    }
    ?>
    <div id="header">
        <label>Essentials</label>
    </div>
    <div id="body">
        <table width="80%" border="0">
            <tr>
                <td>Name</td>
                <td>File Type</td>
                <td>File Size</td>
            </tr>
            <?php
            //path to directory to scan
            $dir = $_GET['dir'];
            $directory = "/wamp/www/SIGUPLOAD".$dir;
            //get all files in specified directory
            $files = glob($directory . "*");
            if (empty($files)) {
               ?>
                <tr>
                    <td colspan="3">
                        Nothing to show
                    </td>
                </tr>
                <?php
            }
            //print each file name
            foreach($files as $file)
            {
            //check to see if the file is a folder/directory
                ?><tr align="left"><?php
                if(is_dir($file))
                {
                    $ndir = str_replace("/wamp/www/SIGUPLOAD",'', $file);
                    $address="Essentials.php?dir=".$ndir."/";
                    ?>
                    <td colspan="3"><a href="<?php echo $address; ?>"><?php echo basename($file);?></a></td>
                    <?php
                }else{
                   ?>
                   <td><?php echo basename($file); ?>
                    <?php $ndir = str_replace("/wamp/www",'', $file); ?> 
                    (<a href="<?php echo $ndir ?>" target="_blank">view</a>)</td>
                    <td><?php echo pathinfo($file, PATHINFO_EXTENSION); ?></td>
                    <td><?php echo filesize($file); ?></td>
                    <?php
                }
                ?></tr><?php
            }
            if($dir != '/Essentials/'){
                $temp = rtrim($dir,'/');
                while(substr($temp, -1) != "/"){
                    $temp = substr($temp, 0, -1);
                }
                $address ="Essentials.php?dir=".$temp;
                ?>
                <tr align="left">
                 <td colspan ="3"><a href="<?php echo $address; ?>">Back</a></td>
             </tr>
             <?php
         }
         ?>
     </table>

 </div>
</body>
</html>