#include<iostream>
using namespace std;
class merge{
	public :
	//void input(int A[],int);
	
	void simplemerge(int A[],int l,int m, int h){
	int i,j,temp[10],k;
	i=l;
	k=l;
	j=m+1;
	while((i<=m)&&(j<=h)){
		if(a[i]<a[j]){
			temp[k++]=A[i++];
		}else{
			temp[k++]=A[j++];
		}
		while(i<=m){
			temp[k++]=A[i++];
		}
		while(j<=n){
			temp[k++]=A[j++];
		}
			for(i=l;i<=k;i++){
				a[i]=temp;
			}
		}
			
	}
void mergesort(int A[],int l,int h){
	int m;
	m=(l+h)/2;
	mergesort(a,l,m);
	mergesort(a,m+1,h);
	simplemerge(a,l,m,h);
	
}	
};
main(){
	int i,j,a[30],M,temp;
	merge KA;
	cout<<"ENTER M";
	cin>>M
	cout<<"ENTER ELEMENTS";
	for(i=1;i<=M;i++){
		cin>>a[i];
	}
	mergesort(a,0,M-1);
	cout<<"ENTER SORTED ELEMENTS";
	for(i=1;i<=M;i++){
		cin>>a[i];
	}
}
