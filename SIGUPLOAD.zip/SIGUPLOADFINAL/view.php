<?php
include_once 'dbconfig.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>File Uploading With PHP and MySql</title>
    <link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>
    <div id="header">
        <label>ADMIN View</label>
    </div>
    <div id="body">
        <table width="80%" border="0">
            <tr>
                <td>Faculty Folders</td>
            </tr>
            <?php
            $directory = "/xampp/htdocs/SIGUPLOAD/Essentials/";
            $files = glob($directory . "*");
            if (empty($files)) {
                ?>
                <tr>
                    <td colspan="3">
                        Nothing to show
                    </td>
                </tr>
                <?php
            }
            //print each file name
            foreach($files as $file)
            {
                //check to see if the file is a folder/directory
                ?><tr align="left"><?php
                if(is_dir($file))
                {
                    $ndir = str_replace("/xampp/htdocs/SIGUPLOAD",'', $file);
                    $address="faculty_directory.php?dir=".$ndir."/";
                    ?>
                    <td colspan="3"><a href="<?php echo $address; ?>"><?php echo basename($file);?></a>
                        <form action="upload.php" method="post">
                            <input type="hidden" name="file" value="<?php echo $file ?>">
                            <button type="submit" name="del_dir">Delete</button>
                        </form>
                    </td>
                    <?php
                }
                ?></tr><?php
            }
            ?>
            <tr>
                <td colspan="3">
                    <form action="upload.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="dir" id="dir" value="<?php echo $directory ?>" ><br>
                        <input type="text" name="new_dir" placeholder="Enter Name of the Folder">
                        <button type="submit" name="dir-upload">Create</button>
                    </form>
                </td>
            </tr>
            <table width="80%" border="1">
                <tr>
                    <td>File Name</td>
                    <td>File Type</td>
                    <td>Path </td>
                    <td>Uploaded By</td>    
                    <td>Date Time </td>
                    <td>Operation </td>
                </tr>
                <?php
                $sql="SELECT * FROM tbl_uploads";
                $result_set=mysqli_query($con,$sql) or die("<td colspan='6'>Nothing to Show</td>");
                {
                    $this->foo = $foo;
                };
                while($row=mysqli_fetch_array($result_set))
                {
                  ?>
                  <tr>
                    <td><?php echo $row[0] ?></td>
                    <td><?php echo $row[1] ?></td>
                    <td><a href="Essentials.php?dir=<?php echo $row[2];?>"><?php echo $row[2] ?></a></td>
                    <td><?php echo $row[3] ?></td>
                    <td><?php echo $row[4] ?></td>
                    <td><?php echo $row[5] ?></td>
                    <td><a href="uploads/<?php echo $row[0] ?>" target="_blank">view file</a></td>
                </tr>
                <?php
            }
            ?>
        </table>

    </div>
</body>
</html>