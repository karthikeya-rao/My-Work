<?php
include_once 'dbconfig.php';
function delete_files($target) {
	if(is_dir($target)){
        $files = glob( $target . '*', GLOB_MARK ); //GLOB_MARK adds a slash to directories returned
        foreach( $files as $file )
        {
        	delete_files( $file );      
        }
        rmdir( $target );
    } elseif(is_file($target)) {
    	unlink( $target );  
    }
}
if(isset($_POST['dir-upload'])){
	$dirname = $_POST['dir'];
	$new_dir = $_POST['new_dir'];
	$new_dir = $dirname.$new_dir;
	$address = str_replace("/xampp/htdocs/SIGUPLOAD",'', $dirname);
	$fac_name = $_SESSION["fac_name"];
	$currdate = date("Y-m-d h:i:s");
	if(mkdir($new_dir)){
		$sql="INSERT INTO tbl_uploads VALUES('$new_dir','FOLDER','$address','$fac_name','$currdate','CREATE')";
		mysqli_query($con,$sql);
		?>
		<script>
			alert('successfully created');
		</script>
		<?php
		header('location:faculty_directory.php?dir='.$address);
	}else{
		?>
		<script>
			alert('Error in creation');
		</script>
		<?php
		header('location:faculty_directory.php?dir='.$address);
	}
}
if(isset($_POST['del_dir'])){
	$dirname = $_POST['file'];
	echo $dirname;
	delete_files($dirname);
	$address = str_replace("/xampp/htdocs/SIGUPLOAD",'', $dirname);
	$address =str_replace(basename($dirname),'', $address);
	$fac_name = $_SESSION["fac_name"];
	$currdate = date("Y-m-d h:i:s");
	$sql="INSERT INTO tbl_uploads VALUES('$dirname','FOLDER','$address','$fac_name','$currdate','DELETE')";
	mysqli_query($con,$sql);
	?>
	<script>
		alert('successfully deleted');
	</script>
	<?php
	header('location:faculty_directory.php?dir='.$address);
}
if(isset($_POST['file-upload']))
{    

	$file = $_FILES['file']['name'];
	$file_loc = $_FILES['file']['tmp_name'];
	$file_size = $_FILES['file']['size'];
	$file_type = $_FILES['file']['type'];
	$folder=$_POST['dir'];	
	// new file size in KB
	$new_size = $file_size/1024;  
	// new file size in KB
	$address = str_replace("/xampp/htdocs/SIGUPLOAD",'', $folder);
	$final_file=str_replace(' ','_',$file);
	$fac_name = $_SESSION["fac_name"];
	$currdate = date("Y-m-d h:i:s");

	if(move_uploaded_file($file_loc,$folder.$final_file))
	{
		$sql="INSERT INTO tbl_uploads VALUES('$final_file','FILE','$address','$fac_name','$currdate','CREATE')";
		mysqli_query($con,$sql);
		?>
		<script>
			alert('successfully uploaded');
		</script>
		<?php
		header('location:faculty_directory.php?dir='.$address);
	}
	else
	{
		?>
		<script>
			alert('error while uploading file');
		</script>
		<?php
		header('location:faculty_directory.php?dir='.$address);
	}
}
if(isset($_POST['del_file'])){
	$dirname = $_POST['file'];
	echo $dirname;
	$address = str_replace("/xampp/htdocs/SIGUPLOAD",'', $dirname);
	$address =str_replace(basename($dirname),'', $address);
	echo $address;
	unlink($dirname);
	$fac_name = $_SESSION["fac_name"];
	$currdate = date("Y-m-d h:i:s");
	$sql="INSERT INTO tbl_uploads VALUES('$dirname','FILE','$address','$fac_name','$currdate','DELETE')";
	mysqli_query($con,$sql);
	?>
	<script>
		alert('successfully created');
	</script>
	<?php
	header('location:faculty_directory.php?dir='.$address);
}
?>